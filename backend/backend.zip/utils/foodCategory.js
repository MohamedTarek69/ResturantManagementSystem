const Category = {
    seaFood : "SeaFood",
    italian : "Italian Food",
    oriental : "Oriental Food",
    Dessert : "Dessert",
    asian : "Asian Food",
}

module.exports = Category;