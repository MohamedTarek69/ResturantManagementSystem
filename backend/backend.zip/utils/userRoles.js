const userRole = {
    admin: 'admin',
    customer: 'customer',
    vendor: 'vendor',
}

module.exports = userRole;