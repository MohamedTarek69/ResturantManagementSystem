const timeslots = {
    twelvePM: '12:00 PM - 2:00 PM',
    twoPM: '2:00 PM - 4:00 PM',
    fourPM: '4:00 PM - 6:00 PM',
    sixPM: '6:00 PM - 8:00 PM',
    eightPM: '8:00 PM - 10:00 PM',
}

module.exports = timeslots;